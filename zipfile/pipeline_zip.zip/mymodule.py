def greetings(name):
  print("zli for , " + name)
